<div align="center">    
    <h2>Portfolio Web From Web Shala | Tria Bagus</h2>
    <a href="https://www.triabagus.site">
        <img src="https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg"></img>
    </a>
    <a href="https://github.com/triabagus/portfolio2020/fork">
        <img src="https://img.shields.io/badge/PRs-welcome-brightgreen.svg"></img>
    </a>   
    <a href="https://www.paypal.me/triabagus/10">
        <img src="https://img.shields.io/badge/$-donate-ff69b4.svg?maxAge=2592000&amp;style=flat"></img>
    </a> 
</div>

## Link Reference
- [CDN Font Awesome](https://www.bootstrapcdn.com/fontawesome/) 
- [Import Font Google](https://fonts.google.com)